package com.android.apteasedashboard

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {

    private lateinit var rentRecycler: RecyclerView
    private lateinit var arRecycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rentRecycler = findViewById(R.id.rentRecycler)
        arRecycler = findViewById(R.id.arRecycler)

        val rentImages = listOf(
            R.drawable.rent_payment,
            R.drawable.rent_payment2,
            R.drawable.rent_payment3
        )

        val arImages = listOf(
            R.drawable.bed1,
            R.drawable.bed2,
            R.drawable.bed3
        )

        rentRecycler.adapter = ImageAdapter(rentImages) { position ->
            Toast.makeText(this, "Clicked Rent Payment $position", Toast.LENGTH_SHORT).show()
        }
        rentRecycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        arRecycler.adapter = ImageAdapter(arImages) { position ->
            Toast.makeText(this, "Clicked AR Property $position", Toast.LENGTH_SHORT).show()
        }
        arRecycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
    }
}